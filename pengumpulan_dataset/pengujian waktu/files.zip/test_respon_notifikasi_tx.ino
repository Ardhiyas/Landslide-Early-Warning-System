/*
  =====================================================================
  TANAALERT - PENGUJIAN WAKTU RESPON & NOTIFIKASI (TRANSMITTER)
  Tabel 3.13 dan Tabel 3.14 Skripsi
  =====================================================================
  Transmitter ini mengirim 3 skenario kondisi secara bergiliran:
    Skenario 1 : AMAN   (stabil, tidak ada hujan)
    Skenario 2 : WASPADA (hujan ringan + tanah lembap)
    Skenario 3 : BAHAYA  (hujan deras + tanah jenuh + getaran kuat)

  Data diambil dari dataset nyata (Tabel 4.2 di skripsimu) supaya
  hasil prediksi di receiver bisa dipastikan benar sebelum dicatat
  ke tabel pengujian.

  Setiap skenario dikirim REPEAT_PER_SCENARIO kali sebelum pindah ke
  skenario berikutnya. Ini supaya kamu punya cukup data untuk mengisi
  3 baris di Tabel 3.13 (waktu respon diuji 3x untuk konsistensi).

  WIRING (hanya LoRa):
  VCC->3.3V | GND->GND | RST->GPIO14 | DIO0->GPIO2
  NSS->GPIO5 | SCK->GPIO18 | MISO->GPIO19 | MOSI->GPIO23
  =====================================================================
*/

#include <SPI.h>
#include <LoRa.h>

#define LORA_NSS      5
#define LORA_RST      14
#define LORA_DIO0     2
#define LORA_SCK      18
#define LORA_MISO     19
#define LORA_MOSI     23

#define LORA_FREQUENCY   433E6
#define LORA_SYNC_WORD   0x12
#define NODE_ID          "NODE-07"

// Jeda antar paket dalam satu skenario
#define SEND_INTERVAL_MS    5000UL

// Berapa kali tiap skenario dikirim sebelum pindah ke skenario berikutnya
// -> 3 kali = cukup untuk mengisi 3 baris Tabel 3.13
#define REPEAT_PER_SCENARIO 3

// ====================== DATA SKENARIO (dari dataset nyata) ======================
// Format: rainADC,rainPct,rainStatus,soilADC,soilPct,soilStatus,
//         accelMag,gyroMag,pitch,roll,vibStatus
// Diambil dari Tabel 4.2 skripsi (data yang modelnya sudah terbukti benar)

struct Scenario {
  const char* nama;
  const char* labelAsli;       // untuk validasi di Serial Monitor
  int   rainADC; int rainPct;  const char* rainStatus;
  int   soilADC; int soilPct;  const char* soilStatus;
  float accelMag; float gyroMag; float pitch; float roll;
  const char* vibStatus;
};

const Scenario scenarios[] = {
  // ── SKENARIO 1: AMAN ─────────────────────────────────────────────────
  {
    "AMAN (Stabil)",
    "Aman",
    4095, 0,  "Terang",
    3281, 19, "Kering",
    1.007, 3.59, 3.56, -6.84, "STABIL"
  },
  // ── SKENARIO 2: WASPADA ──────────────────────────────────────────────
  {
    "WASPADA (Hujan Ringan + Tanah Lembap)",
    "Waspada",
    2800, 42, "Gerimis",
    2400, 47, "Lembab",
    1.200, 18.50, 5.20, -8.30, "GETARAN_RINGAN"
  },
  // ── SKENARIO 3: BAHAYA ───────────────────────────────────────────────
  {
    "BAHAYA (Hujan Deras + Tanah Jenuh + Getaran Kuat)",
    "Bahaya",
    978,  76, "Hujan",
    1133, 72, "Basah",
    2.008, 379.45, 47.44, -23.47, "GETARAN_KUAT"
  }
};

const int TOTAL_SCENARIOS = 3;

// ====================== STATE ======================
int  currentScenario = 0;
int  repeatCount     = 0;
unsigned long lastSendTime = 0;
bool waitingConfirm  = false;  // jeda antar skenario, tunggu Enter

void setup() {
  Serial.begin(115200);
  delay(200);
  Serial.println("=== TANAALERT - Pengujian Waktu Respon & Notifikasi (TX) ===");
  Serial.println("Setiap skenario dikirim " + String(REPEAT_PER_SCENARIO) +
                 " kali, lalu pindah ke skenario berikutnya.\n");

  SPI.begin(LORA_SCK, LORA_MISO, LORA_MOSI, LORA_NSS);
  LoRa.setPins(LORA_NSS, LORA_RST, LORA_DIO0);

  if (!LoRa.begin(LORA_FREQUENCY)) {
    Serial.println("[ERROR] LoRa gagal! Periksa wiring.");
    while (1) delay(1000);
  }
  LoRa.setSpreadingFactor(9);
  LoRa.setSignalBandwidth(125E3);
  LoRa.setCodingRate4(5);
  LoRa.setTxPower(17);
  LoRa.setSyncWord(LORA_SYNC_WORD);

  Serial.println("[OK] LoRa siap.\n");
  printScenarioHeader(currentScenario);
  lastSendTime = millis();
}

void loop() {
  // Jeda antar skenario: tunggu Enter dari Serial Monitor
  if (waitingConfirm) {
    if (Serial.available()) {
      Serial.read();
      waitingConfirm = false;
      printScenarioHeader(currentScenario);
      lastSendTime = millis();
    }
    return;
  }

  if (millis() - lastSendTime >= SEND_INTERVAL_MS) {
    sendCurrentScenario();
    lastSendTime = millis();
  }
}

void sendCurrentScenario() {
  const Scenario &sc = scenarios[currentScenario];
  repeatCount++;

  String payload = String(NODE_ID) + "," +
                   sc.rainADC + "," + sc.rainPct + "," + sc.rainStatus + "," +
                   sc.soilADC + "," + sc.soilPct + "," + sc.soilStatus + "," +
                   String(sc.accelMag, 2) + "," +
                   String(sc.gyroMag, 2) + "," +
                   String(sc.pitch, 2) + "," +
                   String(sc.roll, 2) + "," +
                   sc.vibStatus;

  LoRa.beginPacket();
  LoRa.print(payload);
  LoRa.endPacket();

  Serial.printf("  [%d/%d] Terkirim -> %s\n",
                repeatCount, REPEAT_PER_SCENARIO, payload.c_str());
  Serial.println("         Label asli: " + String(sc.labelAsli) +
                 " -> cek receiver apakah prediksi cocok\n");

  // Cek apakah sudah selesai repeat untuk skenario ini
  if (repeatCount >= REPEAT_PER_SCENARIO) {
    repeatCount = 0;
    currentScenario++;

    if (currentScenario >= TOTAL_SCENARIOS) {
      Serial.println("\n==============================================");
      Serial.println("Semua skenario selesai dikirim.");
      Serial.println("Catat hasil dari Serial Monitor RECEIVER ke");
      Serial.println("Tabel 3.13 dan Tabel 3.14 di skripsimu.");
      Serial.println("==============================================");
      while (1) delay(1000);   // berhenti
    } else {
      Serial.println("\n----------------------------------------------");
      Serial.println("Skenario selesai. Tekan Enter di Serial Monitor");
      Serial.println("untuk lanjut ke skenario berikutnya.");
      Serial.println("----------------------------------------------\n");
      waitingConfirm = true;
    }
  }
}

void printScenarioHeader(int idx) {
  const Scenario &sc = scenarios[idx];
  Serial.println("══════════════════════════════════════════════");
  Serial.println("SKENARIO " + String(idx + 1) + ": " + sc.nama);
  Serial.println("Label asli       : " + String(sc.labelAsli));
  Serial.println("Yang diharapkan  : ");
  if (String(sc.labelAsli) == "Aman") {
    Serial.println("  -> Prediksi AMAN, Buzzer MATI, Telegram TIDAK TERKIRIM");
  } else if (String(sc.labelAsli) == "Waspada") {
    Serial.println("  -> Prediksi WASPADA, Buzzer MATI, Telegram TIDAK TERKIRIM");
  } else {
    Serial.println("  -> Prediksi BAHAYA, Buzzer NYALA, Telegram TERKIRIM");
    Serial.println("  -> Catat semua timestamp yang muncul di receiver!");
  }
  Serial.println("Mengirim " + String(REPEAT_PER_SCENARIO) + " paket...");
  Serial.println("══════════════════════════════════════════════\n");
}
