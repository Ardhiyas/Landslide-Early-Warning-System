/*
  =====================================================================
  TANAALERT - PENGUJIAN WAKTU RESPON & NOTIFIKASI (RECEIVER)
  Tabel 3.13 dan Tabel 3.14 Skripsi
  =====================================================================
  Receiver ini SAMA PERSIS dengan receiver utama, dengan tambahan:
  - Timestamp dicatat dan dicetak di setiap TAHAP proses:
      T1: Waktu data diterima gateway (paket LoRa masuk)
      T2: Waktu hasil klasifikasi selesai (Random Forest selesai)
      T3: Waktu alarm buzzer aktif
      T4: Waktu notifikasi Telegram terkirim
      T5: Waktu data selesai dikirim ke Firebase (opsional)
  - Total Respon = T4 - T1 (dari terima data sampai Telegram terkirim)

  OUTPUT SERIAL MONITOR (yang kamu salin ke Tabel 3.13 dan 3.14):

  ══ PAKET DITERIMA ══════════════════════════════
  T1 Terima LoRa     : 10:05:12.345
  [RF] Prediksi      : BAHAYA
  T2 Klasifikasi     : 10:05:12.347  (durasi: 2 ms)
  T3 Buzzer aktif    : 10:05:12.348
  T4 Telegram kirim  : 10:05:14.812
  Total respon       : 2467 ms
  ════════════════════════════════════════════════

  CATATAN KOLOM TABEL:
  - "Waktu Baca Sensor" di Tabel 3.13 = timestamp di Serial Monitor TX
    (catat dari Serial Monitor transmitter, atau estimasi T1 - 5 detik
    karena transmitter kirim tiap 5 detik)
  - "Waktu data diterima gateway" = T1
  - "Waktu alarm aktif" = T3 (tulis "-" jika kondisi Aman/Waspada)
  - "Waktu notifikasi Telegram" = T4 (tulis "-" jika kondisi Aman/Waspada)
  - "Total Respon" = T4 - T1 untuk kondisi Bahaya,
                     T2 - T1 untuk kondisi Aman/Waspada (tidak ada alarm)
  =====================================================================
*/

#include <SPI.h>
#include <LoRa.h>
#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <UniversalTelegramBot.h>
#include <Firebase_ESP_Client.h>
#include "addons/TokenHelper.h"
#include "addons/RTDBHelper.h"
#include "rf_model.h"

// ====================== KONFIGURASI ======================
#define WIFI_SSID      "NAMA_WIFI_ANDA"
#define WIFI_PASSWORD  "PASSWORD_WIFI_ANDA"

#define FIREBASE_HOST          "https://NAMA-PROJECT-default-rtdb.asia-southeast1.firebasedatabase.app/"
#define FIREBASE_API_KEY       "API_KEY_FIREBASE_ANDA"
#define FIREBASE_USER_EMAIL    "email@tanaalert.com"
#define FIREBASE_USER_PASSWORD "password"
#define FIREBASE_PATH_LATEST   "/tanaalert/NODE-07/latest"
#define FIREBASE_PATH_LOG      "/tanaalert/NODE-07/log"

#define TELEGRAM_BOT_TOKEN  "TOKEN_BOT_TELEGRAM"
#define TELEGRAM_CHAT_ID    "CHAT_ID_KAMU"

#define LORA_NSS      5
#define LORA_RST      14
#define LORA_DIO0     2
#define LORA_SCK      18
#define LORA_MISO     19
#define LORA_MOSI     23
#define PIN_BUZZER    4

#define LORA_FREQUENCY   433E6
#define LORA_SYNC_WORD   0x12
#define ALERT_REPEAT_MS  5UL * 60UL * 1000UL

// ====================== OBJEK GLOBAL ======================
WiFiClientSecure  telegramClient;
UniversalTelegramBot bot(TELEGRAM_BOT_TOKEN, telegramClient);
FirebaseData      fbdo;
FirebaseAuth      fbAuth;
FirebaseConfig    fbConfig;

String lastRiskStatus = "AMAN";
unsigned long lastAlertSentTime = 0;

struct ReceivedPacket {
  String nodeId;
  int    rainADC, rainPct;
  String rainStatus;
  int    soilADC, soilPct;
  String soilStatus;
  float  accelMag, gyroMag, pitch, roll;
  String vibStatus;
  bool   valid;
};

void setup() {
  Serial.begin(115200);
  delay(200);
  Serial.println("=== TANAALERT - Pengujian Waktu Respon & Notifikasi (RX) ===");
  Serial.println("Timestamp setiap tahap proses akan ditampilkan.\n");

  pinMode(PIN_BUZZER, OUTPUT);
  digitalWrite(PIN_BUZZER, LOW);

  setupLoRa();
  setupWiFi();
  setupFirebase();
  telegramClient.setInsecure();

  Serial.println("[OK] Receiver siap. Menunggu paket...\n");
}

void loop() {
  int packetSize = LoRa.parsePacket();
  if (packetSize > 0) {
    String raw = "";
    while (LoRa.available()) raw += (char)LoRa.read();
    int rssi = LoRa.packetRssi();

    // ── T1: Waktu data diterima gateway ──────────────────────────────
    unsigned long t1 = millis();
    String waktuT1 = getTimeString();

    Serial.println("\n══ PAKET DITERIMA ══════════════════════════════════════");
    Serial.println("Raw              : " + raw);
    Serial.println("RSSI             : " + String(rssi) + " dBm");
    Serial.println("T1 Terima LoRa   : " + waktuT1 + " (millis=" + String(t1) + ")");

    ReceivedPacket pkt = parsePacket(raw);
    if (!pkt.valid) {
      Serial.println("[WARNING] Paket tidak valid, diabaikan.");
      return;
    }

    processPacket(pkt, rssi, t1, waktuT1);
    Serial.println("════════════════════════════════════════════════════════\n");
  }

  if (WiFi.status() != WL_CONNECTED) setupWiFi();
}

// ====================== PROSES UTAMA ======================
void processPacket(ReceivedPacket &pkt, int rssi,
                   unsigned long t1, String waktuT1) {

  // ── T2: Klasifikasi Random Forest ────────────────────────────────
  unsigned long t2start = millis();
  int riskIdx    = classifyRiskRF(pkt.rainADC, pkt.rainPct,
                                   pkt.soilADC, pkt.soilPct,
                                   pkt.accelMag, pkt.gyroMag,
                                   pkt.pitch, pkt.roll);
  String riskStatus = riskClassToString(riskIdx);
  unsigned long t2 = millis();
  String waktuT2 = getTimeString();

  Serial.println("[RF] Prediksi      : " + riskStatus);
  Serial.println("T2 Klasifikasi     : " + waktuT2 +
                 " (durasi: " + String(t2 - t2start) + " ms)");

  // ── T3: Buzzer ───────────────────────────────────────────────────
  unsigned long t3 = 0;
  String waktuT3 = "-";
  if (riskStatus == "BAHAYA") {
    digitalWrite(PIN_BUZZER, HIGH);
    t3 = millis();
    waktuT3 = getTimeString();
    Serial.println("T3 Buzzer aktif    : " + waktuT3 +
                   " (millis=" + String(t3) + ")");
  } else {
    digitalWrite(PIN_BUZZER, LOW);
    Serial.println("T3 Buzzer          : TIDAK AKTIF (status " + riskStatus + ")");
  }

  // ── Firebase (background, tidak dihitung ke total respon) ────────
  sendToFirebase(pkt, riskStatus, rssi);

  // ── T4: Notifikasi Telegram ───────────────────────────────────────
  unsigned long t4 = 0;
  String waktuT4 = "-";
  bool telegramSent = false;

  bool justBahaya  = (riskStatus == "BAHAYA" && lastRiskStatus != "BAHAYA");
  bool repeatBahaya = (riskStatus == "BAHAYA" &&
                       millis() - lastAlertSentTime >= ALERT_REPEAT_MS);

  if (riskStatus == "BAHAYA" && (justBahaya || repeatBahaya)) {
    String msg = buildAlertMessage(pkt, riskStatus);
    telegramSent = bot.sendMessage(TELEGRAM_CHAT_ID, msg, "");
    t4 = millis();
    waktuT4 = getTimeString();

    if (telegramSent) {
      lastAlertSentTime = millis();
      Serial.println("T4 Telegram kirim  : " + waktuT4 +
                     " (millis=" + String(t4) + ")");
    } else {
      Serial.println("T4 Telegram        : GAGAL TERKIRIM");
    }
  } else if (riskStatus == "BAHAYA") {
    Serial.println("T4 Telegram        : Tidak dikirim (sudah terkirim baru-baru ini)");
  } else {
    Serial.println("T4 Telegram        : TIDAK DIKIRIM (status " + riskStatus + ")");
  }

  lastRiskStatus = riskStatus;

  // ── Ringkasan untuk Tabel 3.13 dan 3.14 ─────────────────────────
  Serial.println("\n--- RINGKASAN UNTUK TABEL SKRIPSI ---");

  // Hitung total respon
  String totalRespon;
  if (riskStatus == "BAHAYA" && t4 > 0) {
    totalRespon = String(t4 - t1) + " ms";
  } else {
    totalRespon = String(t2 - t1) + " ms (sampai klasifikasi)";
  }

  // Tabel 3.13
  Serial.println("[Tabel 3.13 - Waktu Respon]");
  Serial.println("  Waktu Baca Sensor          : catat dari Serial Monitor TX");
  Serial.println("  Waktu Data Diterima Gateway: " + waktuT1);
  Serial.println("  Waktu Alarm Aktif          : " + waktuT3);
  Serial.println("  Waktu Notifikasi Telegram  : " + waktuT4);
  Serial.println("  Total Respon               : " + totalRespon);

  // Tabel 3.14
  Serial.println("[Tabel 3.14 - Notifikasi Peringatan]");
  Serial.println("  Prediksi Sistem  : " + riskStatus);
  Serial.println("  Buzzer Aktif     : " + String(riskStatus == "BAHAYA" ? "YA" : "TIDAK"));
  Serial.println("  Telegram Terkirim: " + String(telegramSent ? "YA" : "TIDAK"));
  Serial.println("  Waktu Kirim      : " + waktuT4);
  Serial.println("  Status           : " + String(telegramSent ? "Berhasil" :
                              (riskStatus != "BAHAYA" ? "Tidak diperlukan" : "Gagal")));
}

// ====================== FUNGSI WAKTU ======================
// Mengembalikan jam:menit:detik.milidetik berdasarkan millis()
// (tidak perlu NTP, cukup untuk mencatat urutan waktu relatif)
String getTimeString() {
  unsigned long ms = millis();
  unsigned long totalSec = ms / 1000;
  unsigned long msPart   = ms % 1000;
  unsigned long sec  = totalSec % 60;
  unsigned long mnt  = (totalSec / 60) % 60;
  unsigned long jam  = totalSec / 3600;

  char buf[20];
  sprintf(buf, "%02lu:%02lu:%02lu.%03lu", jam, mnt, sec, msPart);
  return String(buf);
}

// ====================== SETUP FUNGSI ======================
void setupLoRa() {
  SPI.begin(LORA_SCK, LORA_MISO, LORA_MOSI, LORA_NSS);
  LoRa.setPins(LORA_NSS, LORA_RST, LORA_DIO0);
  if (!LoRa.begin(LORA_FREQUENCY)) {
    Serial.println("[ERROR] LoRa gagal!");
    while (1) delay(1000);
  }
  LoRa.setSpreadingFactor(9);
  LoRa.setSignalBandwidth(125E3);
  LoRa.setCodingRate4(5);
  LoRa.setSyncWord(LORA_SYNC_WORD);
  Serial.println("[OK] LoRa aktif.");
}

void setupWiFi() {
  Serial.print("WiFi");
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  int a = 0;
  while (WiFi.status() != WL_CONNECTED && a < 30) {
    delay(500); Serial.print("."); a++;
  }
  if (WiFi.status() == WL_CONNECTED)
    Serial.println("\n[OK] WiFi: " + WiFi.localIP().toString());
  else
    Serial.println("\n[ERROR] WiFi gagal.");
}

void setupFirebase() {
  fbConfig.api_key      = FIREBASE_API_KEY;
  fbConfig.database_url = FIREBASE_HOST;
  fbAuth.user.email     = FIREBASE_USER_EMAIL;
  fbAuth.user.password  = FIREBASE_USER_PASSWORD;
  fbConfig.token_status_callback = tokenStatusCallback;
  Firebase.begin(&fbConfig, &fbAuth);
  Firebase.reconnectWiFi(true);
  Serial.println("[OK] Firebase diinisialisasi.");
}

// ====================== PARSING PAKET ======================
ReceivedPacket parsePacket(String raw) {
  ReceivedPacket pkt;
  pkt.valid = false;

  const int MAX = 12;
  String f[MAX];
  int cnt = 0, si = 0;
  for (int i = 0; i <= (int)raw.length(); i++) {
    if (i == (int)raw.length() || raw[i] == ',') {
      if (cnt < MAX) f[cnt++] = raw.substring(si, i);
      si = i + 1;
    }
  }
  if (cnt != MAX) return pkt;

  pkt.nodeId     = f[0];
  pkt.rainADC    = f[1].toInt();
  pkt.rainPct    = f[2].toInt();
  pkt.rainStatus = f[3];
  pkt.soilADC    = f[4].toInt();
  pkt.soilPct    = f[5].toInt();
  pkt.soilStatus = f[6];
  pkt.accelMag   = f[7].toFloat();
  pkt.gyroMag    = f[8].toFloat();
  pkt.pitch      = f[9].toFloat();
  pkt.roll       = f[10].toFloat();
  pkt.vibStatus  = f[11];
  pkt.valid      = true;
  return pkt;
}

// ====================== FIREBASE ======================
void sendToFirebase(ReceivedPacket &pkt, String riskStatus, int rssi) {
  if (WiFi.status() != WL_CONNECTED) return;
  FirebaseJson json;
  json.set("nodeId",        pkt.nodeId);
  json.set("rainADC",       pkt.rainADC);
  json.set("rainPct",       pkt.rainPct);
  json.set("rainStatus",    pkt.rainStatus);
  json.set("soilADC",       pkt.soilADC);
  json.set("soilPct",       pkt.soilPct);
  json.set("soilStatus",    pkt.soilStatus);
  json.set("accelMagnitude",pkt.accelMag);
  json.set("gyroMagnitude", pkt.gyroMag);
  json.set("pitch",         pkt.pitch);
  json.set("roll",          pkt.roll);
  json.set("vibStatus",     pkt.vibStatus);
  json.set("riskStatus",    riskStatus);
  json.set("rssi",          rssi);
  json.set("timestamp",     (double)millis() / 1000.0);

  Firebase.RTDB.setJSON(&fbdo, FIREBASE_PATH_LATEST, &json);
  Firebase.RTDB.pushJSON(&fbdo, FIREBASE_PATH_LOG, &json);
}

// ====================== TELEGRAM ======================
String buildAlertMessage(ReceivedPacket &pkt, String riskStatus) {
  String msg = "PERINGATAN BAHAYA TANAH LONGSOR\n";
  msg += "Node    : " + pkt.nodeId + "\n";
  msg += "Status  : " + riskStatus + "\n";
  msg += "----------------------------\n";
  msg += "Hujan   : " + String(pkt.rainPct) + "% (" + pkt.rainStatus + ")\n";
  msg += "Tanah   : " + String(pkt.soilPct) + "% (" + pkt.soilStatus + ")\n";
  msg += "Getaran : " + String(pkt.gyroMag, 1) + " dps (" + pkt.vibStatus + ")\n";
  msg += "Pitch   : " + String(pkt.pitch, 1) + " derajat\n";
  msg += "Roll    : " + String(pkt.roll, 1) + " derajat\n";
  msg += "----------------------------\n";
  msg += "Segera lakukan pengecekan lapangan.";
  return msg;
}
